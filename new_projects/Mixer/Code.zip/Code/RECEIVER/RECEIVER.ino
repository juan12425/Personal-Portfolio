#include <WiFi.h>
#include <esp_now.h>
#include <AccelStepper.h>

#define MotorInterfaceType 4

// =====================================================
// STEPPERS
// =====================================================
AccelStepper stepper2(
  MotorInterfaceType,
  13, 14, 12, 27
);

AccelStepper stepper3(
  MotorInterfaceType,
  26, 33, 25, 32
);

// =====================================================
// ESP NOW STRUCT
// =====================================================
typedef struct struct_message {

  char command[32];

} struct_message;

struct_message incomingMessage;

// =====================================================
// RPM FUNCTION
// =====================================================
void setRPM(AccelStepper &stepper,
            float rpm) {

  float stepsPerSec =

    (rpm * 200.0) / 60.0;

  stepper.setSpeed(stepsPerSec);

  Serial.print("RPM -> ");

  Serial.println(rpm);
}

// =====================================================
// RECEIVE CALLBACK
// =====================================================
void OnDataRecv(const esp_now_recv_info_t *info,
                const uint8_t *incomingData,
                int len) {

  memcpy(
    &incomingMessage,
    incomingData,
    sizeof(incomingMessage)
  );

  String cmd =
    String(incomingMessage.command);

  Serial.print("RX -> ");

  Serial.println(cmd);

  // =====================================================
  // PROJECT B
  // =====================================================
  if (cmd.startsWith("B:")) {

    float rpm =
      cmd.substring(2).toFloat();

    setRPM(stepper2, rpm);
  }

  // =====================================================
  // PROJECT C
  // =====================================================
  else if (cmd.startsWith("C:")) {

    float rpm =
      cmd.substring(2).toFloat();

    setRPM(stepper3, rpm);
  }
}

// =====================================================
// SETUP
// =====================================================
void setup() {

  Serial.begin(115200);

  WiFi.mode(WIFI_STA);

  // =====================================================
  // ESP NOW
  // =====================================================
  if (esp_now_init() != ESP_OK) {

    Serial.println("ESP NOW ERROR");

    return;
  }

  esp_now_register_recv_cb(OnDataRecv);

  // =====================================================
  // STEPPER CONFIG
  // =====================================================
  stepper2.setMaxSpeed(2000);

  stepper3.setMaxSpeed(2000);

  // START STOPPED
  stepper2.setSpeed(0);

  stepper3.setSpeed(0);

  Serial.println("RECEIVER READY");
}

// =====================================================
// LOOP
// =====================================================
void loop() {

  stepper2.runSpeed();

  stepper3.runSpeed();
}