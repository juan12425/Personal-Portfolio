#include <BluetoothSerial.h>
#include <WiFi.h>
#include <esp_now.h>
#include <AccelStepper.h>
#include <ESP32Servo.h>

BluetoothSerial SerialBT;

#define MotorInterfaceType 4

// =====================================================
// STEPPER A
// =====================================================
AccelStepper stepper1(MotorInterfaceType, 33, 2, 32, 15);

// =====================================================
// SERVOS
// =====================================================
Servo servos[6];

const int servoPins[6] = {
  13, 25, 12, 26, 14, 27
};

// =====================================================
// TIMER VARIABLES
// =====================================================
unsigned long targetTimes[6];

bool servoExecuted[6];

bool servoMoving[6];

unsigned long servoMoveStart[6];

// =====================================================
// PROJECT FLAGS
// =====================================================
bool projectADone = false;
bool projectBDone = false;
bool projectCDone = false;

// =====================================================
// RECEIVER MAC ADDRESS
// =====================================================
uint8_t receiverMac[] = {
  0xA4, 0xF0, 0x0F, 0x75, 0x80, 0xF4
};

// =====================================================
// ESP NOW STRUCT
// =====================================================
typedef struct struct_message {

  char command[32];

} struct_message;

struct_message outgoingMessage;

// =====================================================
// HELPER: saber si un índice es servo "invertido"
// (pines 25, 26, 27 -> índices 1, 3, 5)
// =====================================================
bool isInverted(int i) {
  return (i == 1 || i == 3 || i == 5);
}

// =====================================================
// ESP NOW CALLBACK
// =====================================================
void OnDataSent(const wifi_tx_info_t *info,
                esp_now_send_status_t status) {

  Serial.print("ESP-NOW Status: ");

  Serial.println(
    status == ESP_NOW_SEND_SUCCESS ?
    "Success" :
    "Fail"
  );
}

// =====================================================
// SEND TO RECEIVER
// =====================================================
void sendToReceiver(String cmd) {

  cmd.toCharArray(
    outgoingMessage.command,
    32
  );

  esp_now_send(
    receiverMac,
    (uint8_t *) &outgoingMessage,
    sizeof(outgoingMessage)
  );

  Serial.print("Sent -> ");
  Serial.println(cmd);
}

// =====================================================
// RPM FUNCTION
// =====================================================
void setRPM(AccelStepper &stepper,
            float rpm) {

  float stepsPerSec =
    (rpm * 200.0) / 60.0;

  stepper.setSpeed(stepsPerSec);

  Serial.print("RPM: ");
  Serial.println(rpm);
}

// =====================================================
// SET TIMER
// =====================================================
void setTimer(int servoIndex,
              int hours,
              int minutes) {

  unsigned long duration =

    ((unsigned long)hours * 3600000UL) +

    ((unsigned long)minutes * 60000UL);

  targetTimes[servoIndex] =

    millis() + duration;

  servoExecuted[servoIndex] = false;

  Serial.print("Timer Servo ");
  Serial.print(servoIndex);

  Serial.print(" -> ");

  Serial.print(hours);

  Serial.print("h ");

  Serial.print(minutes);

  Serial.println("m");
}

// =====================================================
// OPEN SERVO
// =====================================================
void startServo(int servoIndex) {

  if (servoExecuted[servoIndex]) return;

  servoExecuted[servoIndex] = true;

  servoMoving[servoIndex] = true;

  servoMoveStart[servoIndex] = millis();

  // Invertidos (25, 26, 27): posición activa = 0°
  // Normales (13, 12, 14):   posición activa = 90°
  if (isInverted(servoIndex)) {
    servos[servoIndex].write(0);
  } else {
    servos[servoIndex].write(90);
  }

  Serial.print("Servo ");

  Serial.print(servoIndex);

  Serial.println(" OPEN");
}

// =====================================================
// CLOSE SERVOS NON BLOCKING
// =====================================================
void updateServos() {

  for (int i = 0; i < 6; i++) {

    if (servoMoving[i]) {

      if (millis() - servoMoveStart[i] >= 500) {

        // Invertidos vuelven a 90°, normales vuelven a 0°
        if (isInverted(i)) {
          servos[i].write(90);
        } else {
          servos[i].write(0);
        }

        servoMoving[i] = false;

        Serial.print("Servo ");

        Serial.print(i);

        Serial.println(" CLOSED");
      }
    }
  }
}

// =====================================================
// PROJECT FINISHED
// =====================================================
void checkProjectsFinished() {

  // =========================
  // PROJECT A
  // =========================
  if (!projectADone &&
      servoExecuted[0] &&
      servoExecuted[1]) {

    projectADone = true;

    stepper1.setSpeed(0);

    Serial.println("PROJECT A FINISHED");
  }

  // =========================
  // PROJECT B
  // =========================
  if (!projectBDone &&
      servoExecuted[2] &&
      servoExecuted[3]) {

    projectBDone = true;

    sendToReceiver("B:0");

    Serial.println("PROJECT B FINISHED");
  }

  // =========================
  // PROJECT C
  // =========================
  if (!projectCDone &&
      servoExecuted[4] &&
      servoExecuted[5]) {

    projectCDone = true;

    sendToReceiver("C:0");

    Serial.println("PROJECT C FINISHED");
  }
}

// =====================================================
// SETUP
// =====================================================
void setup() {

  Serial.begin(115200);

  // =====================================================
  // BLUETOOTH
  // =====================================================
  SerialBT.begin("PowderLab");

  SerialBT.setTimeout(20);

  // =====================================================
  // WIFI
  // =====================================================
  WiFi.mode(WIFI_STA);

  // =====================================================
  // ESP NOW
  // =====================================================
  if (esp_now_init() != ESP_OK) {

    Serial.println("ESP NOW ERROR");

    return;
  }

  esp_now_register_send_cb(OnDataSent);

  esp_now_peer_info_t peerInfo = {};

  memcpy(peerInfo.peer_addr,
         receiverMac,
         6);

  peerInfo.channel = 0;

  peerInfo.encrypt = false;

  esp_now_add_peer(&peerInfo);

  // =====================================================
  // STEPPER A
  // =====================================================
  stepper1.setMaxSpeed(2000);

  // START STOPPED
  stepper1.setSpeed(0);

  // =====================================================
  // SERVOS
  // =====================================================
  for (int i = 0; i < 6; i++) {

    servos[i].setPeriodHertz(50);

    servos[i].attach(
      servoPins[i],
      500,
      2400
    );

    // Invertidos (25, 26, 27) arrancan en 90°
    // Normales (13, 12, 14)   arrancan en 0°
    if (isInverted(i)) {
      servos[i].write(90);
    } else {
      servos[i].write(0);
    }

    targetTimes[i] = 0;

    servoExecuted[i] = false;

    servoMoving[i] = false;
  }

  Serial.println("MASTER READY");
}

// =====================================================
// LOOP
// =====================================================
void loop() {

  // =====================================================
  // RUN STEPPER
  // =====================================================
  stepper1.runSpeed();

  // =====================================================
  // UPDATE SERVOS
  // =====================================================
  updateServos();

  // =====================================================
  // CHECK TIMERS
  // =====================================================
  for (int i = 0; i < 6; i++) {

    if (!servoExecuted[i] &&

        targetTimes[i] > 0 &&

        millis() >= targetTimes[i]) {

      startServo(i);
    }
  }

  // =====================================================
  // PROJECT COMPLETE
  // =====================================================
  checkProjectsFinished();

  // =====================================================
  // BLUETOOTH COMMANDS
  // =====================================================
  if (SerialBT.available()) {

    String cmd =

      SerialBT.readStringUntil('\n');

    cmd.trim();

    if (cmd.length() == 0) return;

    Serial.print("CMD -> ");

    Serial.println(cmd);

    // =====================================================
    // PROJECT A RPM
    // =====================================================
    if (cmd.startsWith("A:")) {

      float rpm =

        cmd.substring(2).toFloat();

      setRPM(stepper1, rpm);

      // RESET PROJECT A
      projectADone = false;

      servoExecuted[0] = false;

      servoExecuted[1] = false;
    }

    // =====================================================
    // PROJECT B RPM
    // =====================================================
    else if (cmd.startsWith("B:")) {

      sendToReceiver(cmd);

      projectBDone = false;

      servoExecuted[2] = false;

      servoExecuted[3] = false;
    }

    // =====================================================
    // PROJECT C RPM
    // =====================================================
    else if (cmd.startsWith("C:")) {

      sendToReceiver(cmd);

      projectCDone = false;

      servoExecuted[4] = false;

      servoExecuted[5] = false;
    }

    // =====================================================
    // A1 TIMER
    // =====================================================
    else if (cmd.startsWith("A1T:")) {

      int sep = cmd.indexOf(':', 4);

      if (sep > 0) {

        int h =
          cmd.substring(4, sep).toInt();

        int m =
          cmd.substring(sep + 1).toInt();

        setTimer(0, h, m);
      }
    }

    // =====================================================
    // A2 TIMER
    // =====================================================
    else if (cmd.startsWith("A2T:")) {

      int sep = cmd.indexOf(':', 4);

      if (sep > 0) {

        int h =
          cmd.substring(4, sep).toInt();

        int m =
          cmd.substring(sep + 1).toInt();

        setTimer(1, h, m);
      }
    }

    // =====================================================
    // B1 TIMER
    // =====================================================
    else if (cmd.startsWith("B1T:")) {

      int sep = cmd.indexOf(':', 4);

      if (sep > 0) {

        int h =
          cmd.substring(4, sep).toInt();

        int m =
          cmd.substring(sep + 1).toInt();

        setTimer(2, h, m);
      }
    }

    // =====================================================
    // B2 TIMER
    // =====================================================
    else if (cmd.startsWith("B2T:")) {

      int sep = cmd.indexOf(':', 4);

      if (sep > 0) {

        int h =
          cmd.substring(4, sep).toInt();

        int m =
          cmd.substring(sep + 1).toInt();

        setTimer(3, h, m);
      }
    }

    // =====================================================
    // C1 TIMER
    // =====================================================
    else if (cmd.startsWith("C1T:")) {

      int sep = cmd.indexOf(':', 4);

      if (sep > 0) {

        int h =
          cmd.substring(4, sep).toInt();

        int m =
          cmd.substring(sep + 1).toInt();

        setTimer(4, h, m);
      }
    }

    // =====================================================
    // C2 TIMER
    // =====================================================
    else if (cmd.startsWith("C2T:")) {

      int sep = cmd.indexOf(':', 4);

      if (sep > 0) {

        int h =
          cmd.substring(4, sep).toInt();

        int m =
          cmd.substring(sep + 1).toInt();

        setTimer(5, h, m);
      }
    }
  }
}